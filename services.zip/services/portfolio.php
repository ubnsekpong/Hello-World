<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="TechForest Tech Forest Product and Services Digital Marketing, Web Development Startup ICT Company in Akwa Ibom State Nigeria Niger Delta">
  <meta name="author" content="Ubong Nsekpong">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
    crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css" />
  <link rel="stylesheet" type="text/css" href="resources/css/style.css">
  <title>Our Portfolio</title>
  
  <link rel="apple-touch-icon" sizes="180x180" href="/resources/img/favicon-16x16.png">
<link rel="icon" type="image/png" sizes="32x32" href="/resources/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/resources/img/favicon.ico">
<link rel="manifest" href="/resources/img/favicon_package_v0.16.zip">
<link rel="mask-icon" href="/resources/img/favicon/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="/resources/img/favicon/favicon.ico">
<meta name="msapplication-TileColor" content="#00a300">
<meta name="msapplication-config" content="resources/img/favicon/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
  
  
  <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=5ecfdd8d2978280013bc9da9&product=inline-share-buttons" async="async"></script>

  
</head>

<body>
 
 <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v7.0&appId=1473848422652078&autoLogAppEvents=1"></script>
 
  <nav class="navbar navbar-expand-sm navbar-dark bg-secondary">
    <div class="container">
      <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
       <a class="navbar-brand" href="index.php"><img src="resources/img/techforest_small_transparent.png" alt="TechForest logo" class="logo"></a>
        <span class="navbar-toggler-icon"></span>
      </button> 
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a href="index.php" class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a href="portfolio.html" class="nav-link">Portfolio</a>
          </li>
          <li class="nav-item">
            <a href="href=https://techforest.ng" target="_blank" class="nav-link">Our Blog</a>
          </li>
          <li class="nav-item">
            <a href="contact.php" class="nav-link">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- PAGE HEADER -->
  <header id="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-6 m-auto text-center">
          <h1>Our Portfolio</h1>
          <p>Here we will only attempt to detail our Products and Services</p>
        </div>
      </div>
    </div>
  </header>
  
  
  <section>
        <div class="container mb-4">
          <div class="row">
          <div class="col-md-8 mt-4 shadow">
             <h4 class="mt-4 text-danger"><i>Is your Business bringing the necessary income?</i></h4>

<h1 class="pt-3">Learn More about us and Get the Necessary Solutions to your Stagnating Business</h1>

<div class="text-justify pt-5">

<p>Did you know that as at April 2020, 4.57 billion people were active internet users globally? This number encompasses 59 percent of the world population according to <a href="https://www.statsoft.de/en/home" target="_blank">statista.com.</a></p> 

<p>As you go through this article which displays our Portfolio, I want you to take some seconds and think about how this can impact your business.  However I will not focus on the world population of internet users but your zone.</p> 

<p>There is practically no continent in the world that does not have internet presence though the number of active users differs depending on the continent.</p>

<p>However in Africa where there are several bottlenecks to the usage of internet, 500 million+ users are active out of the 1 billion+ population in the continent.</p>

<p>In Nigeria, there were almost 50 million mobile internet users and mobile phone internet usage is particularly popular.</p> 

<p>In 2018, 47.1 percent of the Nigeria population were internet users.  This share is projected to grow to 84.5 percent in 2023. The number keep rising.</p> 

<p>However <a href="https://www.premiumtimesng.com/news/more-news/306996-nigerias-internet-users-hit-111-6m-in-december-ncc.html" target="_blank">Premium Times</a> reported that in 2018 December, the Nigeria Communication Communications (NCC) announced that 111 million+ Nigerians were on the internet.</p> 

<p>Think about this and consider how many people pass by your shop daily to see what you have in there? Now pause a minute and think about the traffic you miss daily online.</p> 

<p>Have you set up bill boards? How many people do you think will look at your bill board daily to see what is put up there? That is why we are here for you.</p>

<h3>Our Web Development Solution</h3> 
<p class="pt-3 pt-3">Considering the huge number of people using the internet daily, our IT Startup comprise of a team of young people who are specialized in various skills in web component development.</p> 

<p>That sounds common. But we add several other strategies to make sure the websites we develop for our clients meets Google’s standard so that while your prospective customers search for your product in Google, your site can comfortably pop up.</p>

<p>User Interface (UI) and the User Experience (UX) is very important while laying out our design.  Therefore we put in a lot of resources in building the frontend of your application.</p>  

<p>This is where the user interacts with your app. If the user is not conversant with the placement of components or having problem is readability, he/she may likely quit your application before considering your offers.</p> 

<p>So we put the users first in our designs and we have always had the best results after launching our applications.</p> 

<p>It is estimated that 50million Nigerians are using mobile internet. That means they access the internet via their mobile devices.</p> 

<p>Therefore we have competent hands who develop frontend designs using bootstrap 4.  This makes your application completely mobile friendly and is excellent on PCs. You can’t miss any customer with our design.</p> 

<p>PHP is used in developing most dynamic websites around the world. Therefore for a flexible backend we have expert hands in PHP (though we also use other languages and frameworks like Python and React as required by the client).</p>

<p>However, for blogs and newspaper websites we may use wordpress since this can eaily be managed by our clients when we handover the project. </p> 

<p>Such project include <a href="https://thedune.ng/" target="_blank">The Dune Newspaper</a> and many other blogs we've built in the past. Our services is always guaranteed as you can see it in <a href="#testimonials">our testimonial</a> section.</p>



<h3>Digital Marketing</h3> 

<p>What stands us out from other Web Development Companies is the effort we put into making your site. Usually we add this little extra cost to help you make a proper budget</p>  

<p>We put in our expertise in developing a good Search Engine Optimisation (SEO) for your website so it is optimally visible to the search engines.</p> 

<p>While putting up contents for your site we consider various keywords and narrow them down to make sure your site is properly ranked.</p> 

<p>Except for few clients who provide us with contents, we analyse your business and create contents you because we know that a good content is what sells your website and your business.</p> 

<p>Do you have social media handles already? If no, then we create social media pages and handles that will help you market your products through various social media platforms and also <a href="#train">train your staff</a>  on how to use them efectively.</p> 

<p>However, our digital marketing services do not end with the sites we have built.  We have taken over the management of several sites for various clients developing copy and content to really make the site salable.</p> 

<p>Therefore if you have not made enough sales from your investment on that website, you can call us up through our <a href="contact.php">contact</a> and we will be glad to fix everything for you. You deserve better sales after investing so much on your website.</p> 

<p>We guarantee to extend our services if our target is not met within the specified time frame in our proposal.  So you have nothing to lose in engaging us.</p>

<h3 id="train">Training</h3>
<p class="pt-3">Most times hiring a consultant to handle your IT Jobs becomes a huge investment on your part.  Some CEOs are scared of exposing their files to a third party.</p> 

<p>That is where we come in. Do you have smart staff that can understand basic computing? We offer training to upgrade their skills and help them put in these required skills into your business.</p> 


<p>Such training program is our just concluded staff training for <a href="https://www.theguidenewspaper.com/" target="_blank">The Guide Newspaper</a> in Uyo, Akwa Ibom State Nigeria</p>

<p>By so doing, you don’t have to be calling on consultants and trainers regularly as we train the trainer.  Under this category we offer corporate training, home training and the catch them young program.</p> 

<p>The catch them young program is targeted at bringing young people to the knowledge of ICT. Usually the young person has his/her laptop, then we provide the necessary materials needed for the treaining. Where he/she gets stuck we are always available to provide the needed help.</p>

<p>We are currently working on bringing our training programs online though we have initiated the idea through <a href="https://techforest.ng/">our blog.</a></p>


<p>Under the online category we hope to offer advisory programs where we give you manuals online and guarantee to give you aids whenever and wherever you get stuck.  We will model something like what we have on <a href="https://www.udemy.com/" target="_blank">udemy</a></p> 
             
<p>Therefore if you are planning a training package for your kids, staff, benefactors, constituents, etc. <a href="contact.php" target="_blank">contact us</a> as soon as possible as our lines are always open 24/7 or you fill our <a href="contact.php">contact form.</a></p>

              
<p>Thank you as we hope to have a healthy business relationship with you.</p>

              </div>
              <div class="sharethis-inline-share-buttons mt-4 pt-4"></div>
              
                <!-- Contact form for email          -->
             
               <div class="col-md-8 contact mt-5 pt-2">
             <form action="" method="post">
              <h3 class="text-center text-primary">Let's Hear from You</h3> 
                                 
            <div class="form-group">
                <label for="name">Name</label>
                <input class="form-control" type="text" id="name" name="name" placeholder="Your  Name">
            </div>
            <div>
                <label for="email">Email address</label>
                <input class="form-control form-control-lg" type="email" id="email" name="email" placeholder="Your Email">
            </div>
             <div class="form-group">
                <label for="message">Message</label>
                <textarea class="form-control" id="message" name="message" rows="5" placeholder="Type Message"></textarea>
            </div>

              <input class="btn btn-success btn-lg" type="submit" name="submit" value="Send">
            </form>
              </div>
             
              
          </div> 
          
        <div class="col-md-4 bg-light mt-4 aside">
        
           <div class="card mt-2">
            <div class="card-header bg-dark">
                <h2 class="text-danger text-center">About the Founder</h2>
            </div>
            <div class="card-body">
               <img class="img-fluid rounded-circle mb-2 align-items-center" src="resources/img/ubong_nsekpong.jpg" alt="Ubong Nsekpong" >
                <h4 class="card-title text-center"><a href="https://web.facebook.com/ubnsekpong" target="_blank">Ubong Nsekpong</a></h4>
                <p class="card-text text-center">Founder</p>
                
               <button class="btn btn-primary d-block mb-4" data-toggle="collapse" data-target="#collapse-btn-1">Read More</button>

    <div class="collapse mb-2 text-justify" id="collapse-btn-1">
      
 <p><a href="https://twitter.com/ubnsekpong" target="_blank">Ubong Nsekpong</a> is the founder of TechForest SoftTechnologies Ltd. The Company is registered with the Corporate Affairs Commission (CAC) in Nigeria and is licensed to carry out ICT related businesses including but not limited to Web Development, Digital Marketing, Networking, etc.</p>

<p>Nsekpong is a graduate of Communications Engineering from the Federal University of Technology, Owerri (FUTO).</p> 

<p>He did Java Programming during his 6 months industrial training while in the University and actually developed a multimedia application using Java Technology as his final year project to the department of Electrical Electronics Engineering, FUTO.</p> 

<p>He has studied several web technologies and recently acquired certifications in bootstrap and PHP from and online academy – <a href="https://www.udemy.com/" target="_blank">udemy.com</a>. He is currently studying another frontend technology – JavaScript from the academy.</p> 

<p>He is an excellent team player who knows how to get results. His writing skills is out of this world and because of this, he enrolled for a special course in Digital Marketing and Copywriting in the same online academy.</p> 

<p>He has been a major author on our blog – techforest.ng and also do several freelance writing for businesses and politicians. </p> 
        
    </div>
                
                
            </div>
        </div>  
        
        
        
        
               <div class="card mt-3 bg-primary">
            <div class="card-body">
                <h4 class="card-title text-center text-light">Visit Our Blog</h4>
                <p class="text-justify text-light">We have been running a tech blog for a period of 3 years now and the blog is designed to educate people in the Nigeria Niger Delta on the current trends in technology/ICT. It is our dream that more young people will embrace tech for the purpose of poverty alleviation, elimination of restiveness in the region and the development of the industry within the region.</p>
                <div><a class="btn btn-outline-dark text-light" href="https://techforest.ng" target="_blank">Visit Blog</a>
                
                </div>
            </div>
        </div>
                            
                            
           <div class="card mt-3">
            <div class="card-header bg-success">
                <h2 class="text-light text-center">Properties in Uyo</h2>
            </div>
            <div class="card-body">
               <a href="https://web.facebook.com/techforestproperties" target="_blank"> <img class="img-fluid mb-2 align-items-center" src="resources/img/techforest_properties.jpg" alt="TechForest Properties"></a>
                <h4 class="card-title text-center display-6"><a href="https://web.facebook.com/techforestproperties" target="_blank">Like Our Page to Get Updates on All Availbale Properties in Uyo, Akwa Ibom State</a></h4>
                
                <button class="btn btn-outline-danger d-block mb-4" data-toggle="collapse" data-target="#collapse-btn-1"><a href="https://web.facebook.com/techforestproperties" target="_blank">Like our page</a></button>  
                
            </div>
        </div>  
                            
        <div class="fb-page mt-4" data-href="https://www.facebook.com/techforestng/" data-tabs="timeline" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/techforestng/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/techforestng/">TechForest.ng</a></blockquote></div>
                            
      </div>
      </div>
              </div>
  </section>
  
  
  
  
  <!-- ICON BOXES -->
  <section id="icon-boxes" class="p-5">
    <div class="container">
      <div class="row mb-4">
        <div class="col-md-4">
          <div class="card bg-danger text-white text-center">
            <div class="card-body mt-2">
              <i class="fas fa-building fa-3x"></i>
              <h3><a href="https://watbridgehotels.com/" target="_blank">Watbridge Hotels</a></h3>
              <a href="https://watbridgehotels.com" target="_blank"><strong>Here is</strong></a> a fantastic Hotel Booking Application for a Hotel in Uyo, AKS 
            </div>
          </div>
        </div>
        <div class="col-md-4 mt-2">
          <div class="card bg-dark text-white text-center">
            <div class="card-body">
              <i class="fas fa-bullhorn fa-3x"></i>
              <h3><a href="https://thedune.ng/" target="_blank">The Dune Newspaper</a></h3>
              Amazing <a href="https://thedune.ng" target="_blank"><strong>Up to Date Newspaper Website</strong></a> designed with Word Press.
            </div>
          </div>
        </div>
        <div class="col-md-4  mt-2">
          <div class="card bg-danger text-white text-center">
            <div class="card-body">
              <i class="fas fa-comments fa-3x"></i>
              <h3><a href="https://havitechstreams.com/" target="_blank">Havitech Streams</a></h3>
              Havitech Streams is an <a href="https://havitechstreams.com" target="_blank">IPTV website</a> which promotes her product in Nigeria.
            </div>
          </div>
        </div>
      </div>

      <div class="row mb-4">
        <div class="col-md-4  mt-2">
          <div class="card bg-dark text-white text-center">
            <div class="card-body">
              <i class="fas fa-box fa-3x"></i>
              <h3 class="mt-4">Sample Project</h3>
              Restaurant Website Designed with CSS and HTML
            </div>
          </div>
        </div>
        <div class="col-md-4  mt-2">
          <div class="card bg-danger text-white text-center">
            <div class="card-body">
              <i class="fas fa-credit-card fa-3x"></i>
              <h3 class="mt-4">Sample Project</h3>
             A social media interface designed with bootstrap 4
            </div>
          </div>
        </div>
        <div class="col-md-4  mt-2">
          <div class="card bg-dark text-white text-center">
            <div class="card-body">
              <i class="fas fa-coffee fa-3x"></i>
              <h3>Sample Project</h3>
              Digi Mart is our Virtual Book. So we designed this template for promotion and sales.
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- TESTIMONIALS -->
  <section id="testimonials" class="p-4 bg-dark text-white">
    <div class="container">
      <h2 class="text-center">testimonials</h2>
      <div class="row text-center">
        <div class="col">
          <div class="slider" id="testimonials">
            <div>
              <blockquote class="blockquote">
                <p class="mb-0">
                  Ubong Nsekpong and  techforest team did a nice job on our project - www.thedune.ng. The timely delivery of the project and the technical supports he provides are simply amazing. I have no reservations recommending techforest.
                </p>
                <footer class="blockquote-footer"><a href="https://web.facebook.com/abasifreke.effiong.1" target="_blank">Abasifreke Effiong</a>
                  <cite title="Company 1">Editor, The Dune Newspaper</cite>
                </footer>
              </blockquote>
            </div>
            <div>
              <blockquote class="blockquote">
                <p class="mb-0">
                 I have referred techforest to many businesses, and have never found them wanting in the execution of those projects. From moderate pricing and customer relationship, I can only advise anyone to give a try.
                </p>
                  <footer class="blockquote-footer"><a href="https://web.facebook.com/daniel.ekanem.14" target="_blank">Daniel Ekanem</a>
                  <cite title="Daniel Ekanem">Public Speaker/Communication Expert</cite>
                </footer>
              </blockquote>
            </div>
            <div>
              <blockquote class="blockquote">
                <p class="mb-0">
                  With over 5 years of positive working relationship, I have come to trust techforest and his entire team. Recently I gave them the opportunity to train my staff at The Guide Newspaper, Uyo in Akwa Ibom State, Nigeria on site maintenance and SEO. The result is amazing.  </p>
                  <footer class="blockquote-footer"><a href="https://web.facebook.com/EMASAM4REAL" target="_blank">Emmanuel Sam</a>
                  <cite title="Company 3">SA to AKS Governor</cite>
                </footer>
              </blockquote>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer id="main-footer" class="text-center p-4">
    <div class="container">
      <div class="row">
        <div class="col">
          <p>Copyright &copy;
            <span id="year"></span>TechForest</p>
        </div>
      </div>
    </div>
  </footer>


 
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>

  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());

    $('.slider').slick({
      infinite: true,
      slideToShow: 1,
      slideToScroll: 1
    });
  </script>
</body>

</html>