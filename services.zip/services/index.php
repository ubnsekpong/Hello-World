<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="TechForest Tech Forest Digital Marketing, Web Development Startup ICT Company in Akwa Ibom State Nigeria Niger Delta">
  <meta name="author" content="Ubong Nsekpong">
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
    crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="resources/css/style.css">


  <title>TechForest Products & Services</title>
</head>

   <body>
       <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v7.0&appId=1473848422652078&autoLogAppEvents=1"></script>
       
        <header>
        
            <nav class="navbar navbar-expand-sm navbar-dark mb-2">            
        <div class="container">
           <a class="navbar-brand" href="index.php"><img src="resources/img/techforest%20transparent%20logo.png" alt="TechForest logo" class="logo"></a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link  text-light" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  text-light" href="#products">Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  text-light" href="portfolio.php">Portfolios</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  text-light" href="https://techforest.ng" target="_blank">Our Blog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  text-light" href="contact.php">Contact</a>
                </li>
            </ul>
        </div>
    </nav>
            <div class="container">
        <div class="col-sm-6 col-md-8 col-lg-9 col-xl-10 mt-5">
            <h1 class="text-info">Struggling with your Business?<br> Try Us</h1>
            <h5 class="text-danger"><i>...Building Networks for Your Business</i></h5>
            <a class="btn btn-success text-light" href="portfolio.php">Learn More</a>
            <a class="btn btn-outline-success text-light" href="contact.php">Contact Us</a>
            </div>
            </div>
        
        </header>
        
        <!-- Our Products -->
        
        <section id="home-icons" class="py-5">
    <div class="container bg-light">
     
     <h1 class="display3 mb-4 text-center text-danger" id="products"><a href="portfolio.php" target="_blank">Our Products</a></h1>
     
      <div class="card-columns">
            <div class="card">
                <img class="card-image-top img-fluid" src="./resources/img/web-development.jpeg" alt="">
                <div class="card-body">
                    <h4 class="card-title text-danger text-center">Web Development</h4>
                    <p class="card-text">Our lead developer has gained many years experience in Web Development and has been the backbone of many great projects we have handled. <a href="portfolio.php" target="_blank">Check out our Portfolio</a></p>
                </div>
        </div>
           
            <div class="card">
                <img class="card-image-top img-fluid" src="./resources/img/digital-marketing.jpg" alt="">
                <div class="card-body">
                    <h4 class="card-title text-danger text-center">Digital Marketing</h4>
                    <p class="card-text">Creating excellent contents is what stands us out from the pack.  SEO and Social Media marketing tops our concern. <a href="portfolio.php" target="_blank">Check out Our Portfolio</a></p>
                </div>
        </div>
           
            <div class="card">
                <img class="card-image-top img-fluid" src="./resources/img/training.jpg" alt="">
                <div class="card-body">
                    <h4 class="card-title text-danger text-center">Training</h4>
                    <p class="card-text">Giving back to the society is our way of life and we do this by raising youngsters in the tech industry. Currently we are working on a concrete online training platform. <a href="portfolio.php" target="_blank">Portfolio</a></p>
           
            </div>
        </div>
    </div>
</div>
</section>
      
      
<section class="bg-secondary">
  <div class="container bg-light">
   <div class="row mb-4">
    
    
    <div class="col-md-8 pt-4">
        
      <div class="card text-white">
            <img class="card-img page-header" src="resources/img/property.jpg" alt="TechForest Properties">
            <div class="card-img-overlay">
                <h4 class="card-title display-3">TechForest Properties</h4>
                <p class="card-text">Using a wide range of digital technology we connect you to affordable properties within and outside the Uyo Capital City, Akwa Ibom State.</p>
                
            </div>
        </div>
         <a class="btn btn-success btn-lg" href="https://twitter.com/Techforestpro" target="_blank">Follow Us</a>
        
    </div>
              
     
     
    <div class="col-md-4 pb-5">
        
        <div class="fb-page mt-4" data-href="https://facebook.com/techforestproperties" data-tabs="timeline" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://facebook.com/techforestproperties" class="fb-xfbml-parse-ignore"><a href="https://facebook.com/techforestproperties">TechForest.ng</a></blockquote></div>
      
    </div>          
              
            
    </div>          
    </div>
</section>
       
       
       <!-- PORTFOLIO -->
  
  <section id="home-heading" class="p-2 bg-primary">
   
    <div class="dark-overlay">
      <div class="row">
        <div class="col">
          <div class="container">
            <h1 class="py-3">Our Portfolio</h1>
              <p class="d-none d-md-block"><h6>Are you ready to give us a try? Click the button below to take a look at our various projects and some of our demo projects</h6></p>
          </div>
          <a class="btn btn-danger text-light my-4" href="portfolio.php"><h5>Check this out</h5> </a>
        </div>
      </div>
    
        </div>
  </section>
       
                
                <!--TESTIMONIALS -->
       
        <section class="section-testimonials">
           <div class="container">
            <div>
                <h2 class="text-center pt-4">We Have Satisfied Many</h2>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <blockquote>
                        Ubong Nsekpong and  techforest team did a nice job on our project - <a href="https://thedune.ng/" target="_blank">www.thedune.ng</a> The timely delivery of the project and the technical supports he provides are simply amazing. I have no reservations recommending techforest. <p>&nbsp</p>
                        <div class="media">
                            <cite><img class="mr-3" src="resources/img/abasifreke_effiong.jpg" alt="Abasifreke Effiong"></cite>
            <div class="media-body">
                <h6 class="mt-4"><a href="https://web.facebook.com/abasifreke.effiong.1" target="_blank">Abasifreke Effiong</a></h6>
               Editor, The Dune Newspaper
            </div>
            
        </div>
                    </blockquote>
                </div>
                <div class="col-md-4 col-sm-6">
                    <blockquote>
                       I have referred techforest to many businesses, and have never found them wanting in the execution of those projects.  From moderate pricing and customer relationship, I can only advise anyone to give a try.<p>&nbsp</p>
                        <div class="media">
                            <cite><img class="mr-3" src="resources/img/daniel_ekanem.jpg" alt="Daniel Ekanem"></cite>
            <div class="media-body">
                <h6 class="mt-4"><a href="https://web.facebook.com/daniel.ekanem.14" target="_blank"> Daniel Ekanem</a></h6>
               Public Speaker/Communication Expert
            </div>
            
        </div>
                    </blockquote>
                </div>
                <div class="col-md-4 col-sm-6">
                    <blockquote>
With over 5 years of positive working relationship, I have come to trust techforest and his entire team. Recently I gave them the opportunity to train my staff at <a href="https://www.theguidenewspaper.com" target="_blank">The Guide Newspaper</a>, Uyo in Akwa Ibom State, Nigeria on site maintenance and SEO. The result is amazing.
                            <div class="media">
                            <cite><img class="mr-3" src="resources/img/emmanuel_sam.jpg" alt="Emmanuel Sam"></cite>
            <div class="media-body">
                <h6 class="mt-4"><a href="https://web.facebook.com/EMASAM4REAL" target="_blank">Emmanuel Sam</a></h6>
               SA to AKS Governor
            </div>
            
        </div>
                    </blockquote>
                </div>
            </div>
            </div>
        </section>
      
            
             <?php 
       
                if (isset($_POST['submit'])){
       
                    $to = "ubongnsekpong@gmail.com";
                    $name = $_POST['name'];
                    $message = $_POST['message'];
                }
                ?>
                      
         
          <section id=info class="pt-3">
          <div class="container mb-4">
          <div class="row">
          <div class="col-md-6 contact">
             <form action="" method="post">
              <h3 class="text-center text-primary">Contact Us</h3> 
                                 
            <div class="form-group">
                <label for="name">Name</label>
                <input class="form-control" type="text" id="name" name="name" placeholder="Your  Name">
            </div>
            <div>
                <label for="email">Email address</label>
                <input class="form-control form-control-lg" type="email" id="email" name="email" placeholder="Your Email">
            </div>
             <div class="form-group">
                <label for="message">Message</label>
                <textarea class="form-control" id="message" name="message" rows="5" placeholder="Type Message"></textarea>
            </div>

              <input class="btn btn-success btn-lg" type="submit" name="submit" value="Send">
            </form>
              </div>
               
               
               
              <div class="col-md-6 mt-3">

        <div class="card" id="carded">
            <a href="https://techforest.ng" target="_blank"><img class="card-img-top" src="resources/img/techforest_blog.jpg" alt="TechForest blog"></a>
            <div class="card-body"><p>&nbsp</p><p>&nbsp</p>
                <a class="btn btn-outline-success btn-block text-danger" href="https://techforest.ng" target="_blank"><h4>Visit Our Blog</h4></a>
            </div>
        </div>
                  
                  
              </div>
              </div>
          </div>
        </section>
        
  
   <!-- FOOTER -->
  <footer id="main-footer" class="text-center p-4">
      <div class="container">
      <div class="row">
        <div class="col">
         
           <nav class="navbar navbar-expand-sm navbar-dark">
           <div class="container">
      <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="index.php"><img src="resources/img/techforest_small_transparent.png" alt="TechForest logo" class="logo"></a>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a href="index.php" class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a href="portfolio.php" class="nav-link">Portfolio</a>
          </li>
          <li class="nav-item">
            <a href="href=https://techforest.ng" target="_blank" class="nav-link">Our Blog</a>
          </li>
          <li class="nav-item">
            <a href="contact.php" class="nav-link">Contact</a>
          </li>
        </ul>
      </div>
      </div>
  </nav>
         
         
         
          <p>Copyright &copy;
            <span id="year"></span> TechForest</p>
        </div>
      </div>
  </div>
  </footer>


  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>

  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());

    $('.slider').slick({
      infinite: true,
      slideToShow: 1,
      slideToScroll: 1
    });
  </script>
</body>

</html>